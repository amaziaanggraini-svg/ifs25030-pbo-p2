package adapter.repository;

import domain.entity.Item;
import domain.repository.IItemRepository;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class ItemRepository implements IItemRepository {
    private final List<Item> items = new ArrayList<>();
    private int nextId = 1;

    @Override
    public Item add(String name, int quantity, String category) {
        Item item = new Item(nextId++, name, quantity, category);
        items.add(item);
        return item;
    }

    @Override
    public boolean updateQuantity(int id, int newQuantity) {
        Item item = findById(id);
        if (item != null) {
            item.setQuantity(newQuantity);
            return true;
        }
        return false;
    }

    @Override
    public boolean delete(int id) {
        Item item = findById(id);
        if (item != null) {
            items.remove(item);
            return true;
        }
        return false;
    }

    @Override
    public Item findById(int id) {
        for (Item item : items) {
            if (item.getId() == id) {
                return item;
            }
        }
        return null;
    }

    @Override
    public List<Item> findAll() {
        return new ArrayList<>(items);
    }

    @Override
    public List<Item> searchByName(String keyword) {
        String lowerKeyword = keyword.toLowerCase();
        return items.stream()
                .filter(item -> item.getName().toLowerCase().contains(lowerKeyword))
                .collect(Collectors.toList());
    }

    @Override
    public List<Item> findAllSortedByNameAsc() {
        List<Item> sorted = new ArrayList<>(items);
        sorted.sort(Comparator.comparing(Item::getName, String.CASE_INSENSITIVE_ORDER));
        return sorted;
    }

    @Override
    public List<Item> findAllSortedByNameDesc() {
        List<Item> sorted = new ArrayList<>(items);
        sorted.sort(Comparator.comparing(Item::getName, String.CASE_INSENSITIVE_ORDER).reversed());
        return sorted;
    }

    @Override
    public List<Item> findAllSortedByQuantityAsc() {
        List<Item> sorted = new ArrayList<>(items);
        sorted.sort(Comparator.comparingInt(Item::getQuantity));
        return sorted;
    }

    @Override
    public List<Item> findAllSortedByQuantityDesc() {
        List<Item> sorted = new ArrayList<>(items);
        sorted.sort(Comparator.comparingInt(Item::getQuantity).reversed());
        return sorted;
    }
}