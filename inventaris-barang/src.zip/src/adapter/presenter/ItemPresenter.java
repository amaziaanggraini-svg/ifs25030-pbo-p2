package adapter.presenter;

import domain.entity.Item;
import java.util.List;

public class ItemPresenter {

    public String formatItemList(List<Item> items) {
        StringBuilder sb = new StringBuilder("Daftar Barang:\n");
        if (items.isEmpty()) {
            sb.append("- Data barang belum tersedia!");
        } else {
            for (int i = 0; i < items.size(); i++) {
                sb.append(formatItem(items.get(i)));
                if (i < items.size() - 1) {
                    sb.append("\n");
                }
            }
        }
        return sb.toString();
    }

    public String formatSortedItemList(List<Item> items) {
        StringBuilder sb = new StringBuilder("Daftar Barang (Terurut):\n");
        if (items.isEmpty()) {
            sb.append("- Data barang belum tersedia!");
        } else {
            for (int i = 0; i < items.size(); i++) {
                sb.append(formatItem(items.get(i)));
                if (i < items.size() - 1) {
                    sb.append("\n");
                }
            }
        }
        return sb.toString();
    }

    public String formatSearchResults(String keyword, List<Item> items) {
        StringBuilder sb = new StringBuilder("Hasil Pencarian: \"").append(keyword).append("\"\n");
        if (items.isEmpty()) {
            sb.append("- Barang tidak ditemukan!");
        } else {
            for (int i = 0; i < items.size(); i++) {
                sb.append(formatItem(items.get(i)));
                if (i < items.size() - 1) {
                    sb.append("\n");
                }
            }
        }
        return sb.toString();
    }

    public String formatItem(Item item) {
        return item.getId() + " | " + item.getName() + " | " + item.getQuantity() + " | " + item.getCategory();
    }
}