package usecase;

import domain.entity.Item;
import domain.repository.IItemRepository;
import java.util.List;

public class ItemUseCase {
    private final IItemRepository repository;

    public ItemUseCase(IItemRepository repository) {
        this.repository = repository;
    }

    public Item addItem(String name, int quantity, String category) {
        return repository.add(name, quantity, category);
    }

    public boolean updateQuantity(int id, int newQuantity) {
        return repository.updateQuantity(id, newQuantity);
    }

    public boolean deleteItem(int id) {
        return repository.delete(id);
    }

    public List<Item> getAllItems() {
        return repository.findAll();
    }

    public List<Item> searchItems(String keyword) {
        return repository.searchByName(keyword);
    }

    public List<Item> getItemsSorted(String sortType) {
        switch (sortType) {
            case "1":
                return repository.findAllSortedByNameAsc();
            case "2":
                return repository.findAllSortedByNameDesc();
            case "3":
                return repository.findAllSortedByQuantityAsc();
            case "4":
                return repository.findAllSortedByQuantityDesc();
            default:
                return null;
        }
    }
}