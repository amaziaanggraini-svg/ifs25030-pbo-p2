package framework.view;

import adapter.presenter.ItemPresenter;
import domain.entity.Item;
import usecase.ItemUseCase;

import java.util.List;
import java.util.Scanner;

public class ItemView {
    private final ItemUseCase useCase;
    private final ItemPresenter presenter;

    public ItemView(ItemUseCase useCase, ItemPresenter presenter) {
        this.useCase = useCase;
        this.presenter = presenter;
    }

    public void show() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println(presenter.formatItemList(useCase.getAllItems()));
            System.out.println("Menu:");
            System.out.println("1. Tambah");
            System.out.println("2. Ubah Stok");
            System.out.println("3. Cari");
            System.out.println("4. Urutkan");
            System.out.println("5. Hapus");
            System.out.println("x. Keluar");
            System.out.print("Pilih : ");

            String choice = scanner.nextLine().trim();

            if (choice.equalsIgnoreCase("x")) {
                break;
            }

            switch (choice) {
                case "1":
                    handleAddItem(scanner);
                    break;
                case "2":
                    handleUpdateQuantity(scanner);
                    break;
                case "3":
                    handleSearchItem(scanner);
                    break;
                case "4":
                    handleSortItem(scanner);
                    break;
                case "5":
                    handleDeleteItem(scanner);
                    break;
                default:
                    System.out.println("[!] Pilihan tidak dimengerti.\n");
                    break;
            }
        }
    }

    private void handleAddItem(Scanner scanner) {
        System.out.print("[Menambah Barang]\nNama (x Jika Batal) : ");
        String name = scanner.nextLine().trim();
        if (name.equalsIgnoreCase("x")) {
            return;
        }

        System.out.print("Jumlah : ");
        String quantityStr = scanner.nextLine().trim();
        int quantity;
        try {
            quantity = Integer.parseInt(quantityStr);
        } catch (NumberFormatException e) {
            System.out.println("[!] Jumlah stok tidak valid!\n");
            return;
        }

        System.out.print("Kategori (x Jika Batal) : ");
        String category = scanner.nextLine().trim();
        if (category.equalsIgnoreCase("x")) {
            return;
        }

        Item item = useCase.addItem(name, quantity, category);
        System.out.println("Berhasil menambah barang: " + presenter.formatItem(item) + "\n");
    }

    private void handleUpdateQuantity(Scanner scanner) {
        System.out.print("[Mengubah Stok]\nID Barang yang diubah (x Jika Batal) : ");
        String idStr = scanner.nextLine().trim();
        if (idStr.equalsIgnoreCase("x")) {
            return;
        }

        int id;
        try {
            id = Integer.parseInt(idStr);
        } catch (NumberFormatException e) {
            System.out.println("[!] ID tidak valid!\n");
            return;
        }

        System.out.print("Jumlah Baru (Kosongkan jika tidak ingin mengubah) : ");
        String newQuantityStr = scanner.nextLine().trim();

        if (newQuantityStr.isEmpty()) {
            System.out.println("Berhasil mengubah stok barang.\n");
            return;
        }

        int newQuantity;
        try {
            newQuantity = Integer.parseInt(newQuantityStr);
        } catch (NumberFormatException e) {
            System.out.println("[!] Jumlah stok tidak valid!\n");
            return;
        }

        boolean success = useCase.updateQuantity(id, newQuantity);
        if (success) {
            System.out.println("Berhasil mengubah stok barang.\n");
        } else {
            System.out.println("[!] Gagal mengubah stok barang dengan ID: " + id + ".\n");
        }
    }

    private void handleSearchItem(Scanner scanner) {
        System.out.print("[Mencari Barang]\nKata Kunci (x Jika Batal) : ");
        String keyword = scanner.nextLine().trim();
        if (keyword.equalsIgnoreCase("x")) {
            return;
        }

        List<Item> results = useCase.searchItems(keyword);
        System.out.println(presenter.formatSearchResults(keyword, results) + "\n");
    }

    private void handleSortItem(Scanner scanner) {
        System.out.println("[Mengurutkan Barang]");
        System.out.println("Pilihan Pengurutan:");
        System.out.println("1. Nama (A-Z)");
        System.out.println("2. Nama (Z-A)");
        System.out.println("3. Jumlah (Terkecil -> Terbesar)");
        System.out.println("4. Jumlah (Terbesar -> Terkecil)");
        System.out.println("x. Batal");
        System.out.print("Pilih : ");

        String sortChoice = scanner.nextLine().trim();
        if (sortChoice.equalsIgnoreCase("x")) {
            return;
        }

        List<Item> sortedItems = useCase.getItemsSorted(sortChoice);
        if (sortedItems == null) {
            System.out.println("[!] Pilihan tidak valid!\n");
        } else {
            System.out.println(presenter.formatSortedItemList(sortedItems) + "\n");
        }
    }

    private void handleDeleteItem(Scanner scanner) {
        System.out.print("[Menghapus Barang]\n[ID Barang] yang dihapus (x Jika Batal) : ");
        String idStr = scanner.nextLine().trim();
        if (idStr.equalsIgnoreCase("x")) {
            return;
        }

        int id;
        try {
            id = Integer.parseInt(idStr);
        } catch (NumberFormatException e) {
            System.out.println("[!] ID tidak valid!\n");
            return;
        }

        boolean success = useCase.deleteItem(id);
        if (success) {
            System.out.println("Berhasil menghapus barang.\n");
        } else {
            System.out.println("[!] Gagal menghapus barang dengan ID: " + id + ".\n");
        }
    }
}