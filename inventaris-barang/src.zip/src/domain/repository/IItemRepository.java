package domain.repository;

import domain.entity.Item;
import java.util.List;

public interface IItemRepository {
    Item add(String name, int quantity, String category);
    boolean updateQuantity(int id, int newQuantity);
    boolean delete(int id);
    Item findById(int id);
    List<Item> findAll();
    List<Item> searchByName(String keyword);
    List<Item> findAllSortedByNameAsc();
    List<Item> findAllSortedByNameDesc();
    List<Item> findAllSortedByQuantityAsc();
    List<Item> findAllSortedByQuantityDesc();
}